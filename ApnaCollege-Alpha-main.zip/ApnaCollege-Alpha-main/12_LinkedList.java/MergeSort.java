import java.util.LinkedList;
public class MergeSort {
    public static void mergeSort(LinkedList<Integer> ll) {

        
    }
    public static void main(String args[]) {
        LinkedList<Integer> ll = new LinkedList<>();
        ll.addLast(4);
        ll.addLast(3);
        ll.addLast(2);
        ll.addLast(1);

        System.out.println(ll); 
    }
}
