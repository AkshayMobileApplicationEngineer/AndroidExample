package Interfaces;

public class Demo {
    public static void main(String[] args) {
        Shape shape=new Circle();
        shape.calculated(8);
    }
}
