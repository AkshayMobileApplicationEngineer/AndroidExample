package Abstraction;

public  class Mychild extends MyClass{
    @Override
    public void lunchRocket() {
        System.out.println("My child class is going to lunch rockrt from NASA");
    }
}
