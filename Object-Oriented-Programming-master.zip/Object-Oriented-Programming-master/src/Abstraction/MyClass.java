package Abstraction;

abstract public class MyClass {

    //Complete Method

    public void cal(){
        System.out.println("Calcutaing result..");
    }

    //abstraction Method

    abstract public void lunchRocket();
    //abstract class can not be Instantiated

    //does not create object
}


