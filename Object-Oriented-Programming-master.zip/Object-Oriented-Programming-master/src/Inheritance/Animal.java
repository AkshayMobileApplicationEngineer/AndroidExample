package Inheritance;

public class Animal {
    String Color="Blue";

    int x=4;

    public void eating(){
        System.out.println("Animal is eating...");
    }
}
