package Polymorphism.Overloading;

public class Demo {
    public static void main(String[] args) {
        System.out.println("this is testing...");
        System.out.println();
        Student student=new Student();
        student.read("Python think");
    }
}
