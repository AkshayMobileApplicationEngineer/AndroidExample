package Polymorphism.Overridding;

public class Overridding {
    public void showDetails(){
        System.out.println("Basic details of Person");
    }
}
