package Polymorphism.Overridding;

public class Employee extends Overridding{
    public void showDetails(){//Run time polymore
        System.out.println("Showing the detail of the Employee");
    }
}
