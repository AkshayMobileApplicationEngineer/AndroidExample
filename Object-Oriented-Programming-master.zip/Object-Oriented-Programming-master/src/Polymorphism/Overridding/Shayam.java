package Polymorphism.Overridding;

public class Shayam extends Overridding{
    public void showDetails(){
        System.out.println("this iis new functionality");
    }
}
