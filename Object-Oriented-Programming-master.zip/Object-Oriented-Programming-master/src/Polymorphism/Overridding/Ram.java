package Polymorphism.Overridding;

public class Ram {
    public void dowork(Overridding overridding){
        System.out.println("Doing Work...............\n");
        overridding.showDetails();
    }
}
