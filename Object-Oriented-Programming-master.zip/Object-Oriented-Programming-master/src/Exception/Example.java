package Exception;

public class Example {
    public static void main(String[] args) {

    }
}
