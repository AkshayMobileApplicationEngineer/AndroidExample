import MyPack.Start;

public class Test {

    public static void main(String[] args) {
        Start start=new Start();
        start.display();
    }
}