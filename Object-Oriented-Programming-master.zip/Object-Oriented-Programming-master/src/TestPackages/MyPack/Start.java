package MyPack;

public class Start {
	public void display() {
		System.out.println("Show the Display() of start clss");
	}
	
}