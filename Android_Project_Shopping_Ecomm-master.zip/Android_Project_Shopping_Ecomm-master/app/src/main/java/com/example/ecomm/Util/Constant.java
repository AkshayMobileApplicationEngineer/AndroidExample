package com.example.ecomm.Util;

public class Constant {

    public static String BASE_URL ="https://dummyjson.com/";

}
