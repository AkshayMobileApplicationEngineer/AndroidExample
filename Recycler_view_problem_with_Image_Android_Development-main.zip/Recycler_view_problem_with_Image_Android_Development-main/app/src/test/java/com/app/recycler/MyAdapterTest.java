package com.app.recycler;

import junit.framework.TestCase;

public class MyAdapterTest extends TestCase {

    public void testOnCreateViewHolder() {
    }

    public void testOnBindViewHolder() {
    }

    public void testGetItemCount() {
    }
}